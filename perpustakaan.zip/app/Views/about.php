<?php $this->extend('template') ?>
<?php $this->section('konten') ?>
<div class="row">
    <div class="col-12">
        <div class="card p-4">
            <h3>Perpustakaan</h3>
            <hr>
            <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Explicabo adipisci quisquam dolore ab provident sequi deserunt odio a. Placeat ex porro iusto cum debitis quis et excepturi distinctio. Distinctio, aut.</p>
        </div>
    </div>
</div>
<?php $this->endSection() ?>